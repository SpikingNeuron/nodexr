window['addDotNetSingletonService'] = (name, dotNetServiceRef) => {
    window[name] = dotNetServiceRef;
};
